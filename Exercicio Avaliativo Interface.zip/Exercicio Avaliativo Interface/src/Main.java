ConsoleLogger

public class Logger {
    private static ConsoleLogger consoleLogger = new ConsoleLogger();
    private static FileLogger fileLogger = new FileLogger();

    public static void enableFileMode() {
        fileLogger.enableFileMode();
    }

    public static void disableFileMode() {
        fileLogger.disableFileMode();
    }

    public static void log(LogLevel level, String message) {
        String formattedMessage = "[" + getCurrentTime() + "] " + "[" + level + "] " + message;
        consoleLogger.log(level, formattedMessage);
        fileLogger.log(level, formattedMessage);
    }

    private static String getCurrentTime() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return dateFormat.format(new Date());
    }
}

FileLogger

        import java.io.FileWriter;
        import java.io.IOException;
        import java.io.PrintWriter;

public class FileLogger {
    private boolean fileMode = false;
    private PrintWriter fileWriter;

    public void enableFileMode() {
        fileMode = true;
        try {
            fileWriter = new PrintWriter(new FileWriter("log.txt"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void disableFileMode() {
        fileMode = false;
        if (fileWriter != null) {
            fileWriter.close();
        }
    }

    public void log(LogLevel level, String message) {
        if (fileMode && fileWriter != null) {
            fileWriter.println(message);
            fileWriter.flush();
        }
    }
}

Logger


        import java.text.SimpleDateFormat;
        import java.util.Date;
public class Logger {
    private static ConsoleLogger consoleLogger = new ConsoleLogger();
    private static FileLogger fileLogger = new FileLogger();

    public static void enableFileMode() {
        fileLogger.enableFileMode();
    }

    public static void disableFileMode() {
        fileLogger.disableFileMode();
    }

    public static void log(LogLevel level, String message) {
        String formattedMessage = "[" + getCurrentTime() + "] " + "[" + level + "] " + message;
        consoleLogger.log(level, formattedMessage);
        fileLogger.log(level, formattedMessage);
    }

    private static String getCurrentTime() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return dateFormat.format(new Date());
    }
}


LogLevel

public enum LogLevel {
    DEBUG, WARNING, ERROR
}

main

        import java.io.IOException;

public class Main {
    public static void main(String[] args) {
        Logger.enableFileMode(); // Ativa o modo de arquivo

        Logger.log(LogLevel.DEBUG, "Isso é uma mensagem de debug.");
        Logger.log(LogLevel.WARNING, "Isso é uma mensagem de aviso.");
        Logger.log(LogLevel.ERROR, "Isso é uma mensagem de erro.");

        Logger.disableFileMode(); // Desativa o modo de arquivo
    }
}
