package br.univille.log;

public interface Logger {
    void log(Level level, String message);
}
