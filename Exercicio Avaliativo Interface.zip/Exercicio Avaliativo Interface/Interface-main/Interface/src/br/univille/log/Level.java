package br.univille.log;

public enum Level {
    DEBUG, WARNING, ERROR
}